
### [allData.pkl](https://drive.google.com/file/d/1RPncsqowISLTQkbcGNwB_x1ZHy6o3Q08/view?usp=sharing)

### [通才比專才更吃香　頂尖人才的五項超能力](https://www.cw.com.tw/article/article.action?id=5091992&utm_campaign=Daily&utm_medium=Social&utm_source=Facebook&fbclid=IwAR1VZWOPc-nTmLUKx_vqyNA2ETOEFsnOA9rMFWIUfnXVH7aPOKVbaIbwHJ4)

### [面試準備只看公司網站絕對死，做到「這一步」才是主管想要的人才](https://buzzorange.com/techorange/2018/11/09/what-quality-does-company-value-most/?fbclid=IwAR0B3wdqTE3opvBrolGFW2-AWnYcv8N8PnpJDtCkj7lbxBezetlnXCUy7qM)

## Data Details
1. 已進行前處理過後的臉書資料：allData.pkl
2. 關聯式分析結果：Apriori.html

## 本週任務
挑選適合的文本進行關聯式分析的資料進行分析。